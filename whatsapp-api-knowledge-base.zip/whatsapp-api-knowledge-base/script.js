// WABA Knowledge Base — Optimized JS (Unix LF)

// ── Mobile nav toggle ──────────────────────────────────────
const menuToggle = document.querySelector(".menu-toggle");
const nav = document.querySelector(".nav");

if (menuToggle && nav) {
  menuToggle.addEventListener("click", () => {
    const isOpen = nav.classList.toggle("open");
    menuToggle.setAttribute("aria-expanded", String(isOpen));
  });
}

// ── Active nav link on click ───────────────────────────────
const navLinks = document.querySelectorAll(".nav a");
const sections = [...document.querySelectorAll("section[id]")];

function setActiveNav(sectionId) {
  navLinks.forEach((a) => {
    a.classList.toggle("active", a.getAttribute("href") === `#${sectionId}`);
  });
}

function getSectionIdForTargetId(targetId) {
  const target = document.getElementById(targetId);
  if (!target) return null;
  const section = target.closest("section[id]");
  return section ? section.id : null;
}

function showOnlySection(sectionId) {
  sections.forEach((section) => {
    section.hidden = section.id !== sectionId;
  });
  setActiveNav(sectionId);
}

function openByHash(hash, { scrollToTarget = true } = {}) {
  const id = (hash || "").replace("#", "").trim();
  const fallbackId = sections[0]?.id || "home";
  if (!id) {
    showOnlySection(fallbackId);
    return;
  }

  const sectionId = getSectionIdForTargetId(id) || id;
  const targetSectionExists = sections.some((section) => section.id === sectionId);
  const finalSectionId = targetSectionExists ? sectionId : fallbackId;

  showOnlySection(finalSectionId);

  if (scrollToTarget) {
    const target = document.getElementById(id) || document.getElementById(finalSectionId);
    if (target) target.scrollIntoView({ behavior: "smooth", block: "start" });
  }
}

navLinks.forEach((link) => {
  link.addEventListener("click", (e) => {
    e.preventDefault();
    const href = link.getAttribute("href") || "";
    const targetId = href.replace("#", "");

    openByHash(`#${targetId}`, { scrollToTarget: false });
    history.replaceState(null, "", `#${targetId}`);
    window.scrollTo({ top: 0, behavior: "smooth" });

    if (nav.classList.contains("open")) {
      nav.classList.remove("open");
      menuToggle.setAttribute("aria-expanded", "false");
    }
  });
});

// ── In-page links: open needed section first ────────────────
document.querySelectorAll('a[href^="#"]').forEach((link) => {
  if (link.closest(".nav")) return;
  link.addEventListener("click", (e) => {
    const href = link.getAttribute("href") || "";
    const id = href.replace("#", "").trim();
    if (!id) return;
    e.preventDefault();
    openByHash(`#${id}`, { scrollToTarget: true });
    history.replaceState(null, "", `#${id}`);
  });
});

window.addEventListener("hashchange", () => {
  openByHash(window.location.hash, { scrollToTarget: false });
});

openByHash(window.location.hash || "#home", { scrollToTarget: false });

// ── Reading progress bar ───────────────────────────────────
const progressBar = document.getElementById("progress-bar");

function updateProgress() {
  if (!progressBar) return;
  const scrollTop = window.scrollY;
  const docHeight = document.documentElement.scrollHeight - window.innerHeight;
  const progress = docHeight > 0 ? scrollTop / docHeight : 0;
  progressBar.style.transform = `scaleX(${progress})`;
}

window.addEventListener("scroll", updateProgress, { passive: true });
updateProgress();

// ── Back to top button ─────────────────────────────────────
const backToTop = document.getElementById("back-to-top");

if (backToTop) {
  window.addEventListener(
    "scroll",
    () => {
      backToTop.classList.toggle("visible", window.scrollY > 400);
    },
    { passive: true }
  );

  backToTop.addEventListener("click", () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  });
}

// ── Tabs ───────────────────────────────────────────────────
const tabButtons = document.querySelectorAll(".tab-btn");
const tabPanels = document.querySelectorAll(".tab-panel");

tabButtons.forEach((btn) => {
  btn.addEventListener("click", () => {
    const targetId = btn.dataset.tab;

    tabButtons.forEach((b) => {
      b.classList.remove("active");
      b.setAttribute("aria-selected", "false");
    });
    tabPanels.forEach((p) => p.classList.remove("active"));

    btn.classList.add("active");
    btn.setAttribute("aria-selected", "true");

    const panel = document.getElementById(targetId);
    if (panel) panel.classList.add("active");
  });

  // Keyboard: arrow keys between tabs
  btn.addEventListener("keydown", (e) => {
    const all = [...tabButtons];
    const idx = all.indexOf(btn);
    if (e.key === "ArrowRight" || e.key === "ArrowDown") {
      e.preventDefault();
      all[(idx + 1) % all.length].focus();
    } else if (e.key === "ArrowLeft" || e.key === "ArrowUp") {
      e.preventDefault();
      all[(idx - 1 + all.length) % all.length].focus();
    }
  });
});

// ── Copy buttons for links ─────────────────────────────────
document.querySelectorAll("a[href^='http']").forEach((link) => {
  if (link.closest(".nav") || link.closest(".footer")) return;

  const wrap = document.createElement("span");
  wrap.className = "copyable-wrap";
  link.parentNode.insertBefore(wrap, link);
  wrap.appendChild(link);

  const btn = document.createElement("button");
  btn.className = "copy-btn";
  btn.textContent = "Копировать";
  btn.setAttribute("aria-label", "Скопировать ссылку");
  wrap.appendChild(btn);

  btn.addEventListener("click", (e) => {
    e.preventDefault();
    navigator.clipboard.writeText(link.href).then(() => {
      btn.textContent = "Скопировано!";
      btn.classList.add("copied");
      setTimeout(() => {
        btn.textContent = "Копировать";
        btn.classList.remove("copied");
      }, 2000);
    });
  });
});

// ── Search ─────────────────────────────────────────────────
const searchInput = document.getElementById("search-input");
const searchResults = document.getElementById("search-results");

if (searchInput && searchResults) {
  // Build index: collect all headings and paragraphs from sections
  const index = [];
  document.querySelectorAll("section[id]").forEach((sec) => {
    const secTitle = sec.querySelector("h1, h2")?.textContent.trim() || "";
    const secId = sec.id;

    sec.querySelectorAll("h2, h3, h4").forEach((h) => {
      index.push({
        text: h.textContent.trim(),
        section: secTitle,
        id: h.id || secId,
        type: "heading",
      });
    });

    sec.querySelectorAll("p, li").forEach((el) => {
      const t = el.textContent.trim();
      if (t.length > 30) {
        index.push({
          text: t.slice(0, 120),
          section: secTitle,
          id: secId,
          type: "text",
        });
      }
    });
  });

  function highlight(text, query) {
    const re = new RegExp(`(${query.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")})`, "gi");
    return text.replace(re, "<mark>$1</mark>");
  }

  function doSearch(q) {
    if (!q || q.length < 2) {
      searchResults.innerHTML = "";
      searchResults.classList.remove("open");
      return;
    }

    const lower = q.toLowerCase();
    const hits = index
      .filter((item) => item.text.toLowerCase().includes(lower))
      .slice(0, 8);

    if (!hits.length) {
      searchResults.innerHTML = `<div class="search-empty">Ничего не найдено</div>`;
      searchResults.classList.add("open");
      return;
    }

    searchResults.innerHTML = hits
      .map(
        (h) =>
          `<div class="search-result-item" tabindex="0" data-id="${h.id}">
            <strong>${highlight(h.text.slice(0, 70), q)}</strong>
            <span style="display:block;font-size:.75rem;opacity:.6;margin-top:1px">${h.section}</span>
          </div>`
      )
      .join("");

    searchResults.classList.add("open");

    searchResults.querySelectorAll(".search-result-item").forEach((item) => {
      const go = () => {
        const target = document.getElementById(item.dataset.id);
        if (target) {
          const targetSection = target.closest("section[id]");
          if (targetSection) {
            showOnlySection(targetSection.id);
            history.replaceState(null, "", `#${item.dataset.id}`);
          }
          target.scrollIntoView({ behavior: "smooth", block: "start" });
        }
        searchResults.classList.remove("open");
        searchInput.value = "";
      };
      item.addEventListener("click", go);
      item.addEventListener("keydown", (e) => {
        if (e.key === "Enter") go();
      });
    });
  }

  searchInput.addEventListener("input", () => doSearch(searchInput.value.trim()));

  document.addEventListener("click", (e) => {
    if (!e.target.closest(".search-wrap")) {
      searchResults.classList.remove("open");
    }
  });

  searchInput.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      searchResults.classList.remove("open");
      searchInput.value = "";
    }
  });
}
